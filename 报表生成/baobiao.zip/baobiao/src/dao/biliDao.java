package dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import domain.Bili;
import xhj.wdc.util.DbManager;

public class biliDao {
	public List returnbili(){
		try {
			String sql="SELECT * from selectbili";
			QueryRunner runner=new QueryRunner(DbManager.getSource());
			return runner.query(sql,new BeanListHandler<Bili>(Bili.class));
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
}
