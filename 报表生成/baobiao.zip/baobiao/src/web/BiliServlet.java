package web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONString;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;

import dao.biliDao;
import xhj.wdc.util.JsonUtil;

/**
 * Servlet implementation class BiliServlet
 */
@WebServlet("/servlet/biliServlet")
public class BiliServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public BiliServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		resp.setCharacterEncoding("utf-8");

		String method = req.getParameter("method");
		method = "listbili";
		if (method.equals("listbili"))
			listbili(resp);
	}

	private void listbili(HttpServletResponse resp) {
		// TODO Auto-generated method stub
		biliDao bilidao = new biliDao();
		List list = bilidao.returnbili();

		// 把得到的数据转化成json字符串后输出
		JsonUtil.list2jsonString(list, resp);
	}

}
